import { StyleSheet, View, Text, FlatList, TextInput, TouchableOpacity, ScrollView } from 'react-native';
import React, { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import DatePicker from 'react-native-datepicker';

const AddProduct = (props) => {
  let itemDateObject;
  const navigation = useNavigation();
  const [name, setName] = useState('Name of the food item');
  const [quantity, setQuantity] = useState('Amount of that food item');
  const [date, setDate] = useState('Date of Expiration of the food item: MM/DD/YY');
  const [color, setColor] = useState('The color of what the food item looks like.');
  const [url, setUrl] = useState('Paste an Image Link of what the food item looks like on the web.');
  const [val, setVal] = useState(0);
  const [Items, setItems] = useState([]);

  const SaveItem = async () => {
    try {
      let tempData = [];
      let cDate = new Date();
      tempData = Items;

      let x = JSON.parse(await AsyncStorage.getItem('ITEMS')) || [];
      x?.map(item => {
        tempData.push(item);
      });

      tempData.push({
        id: tempData?.length,
        name: name,
        quantity: quantity,
        date: date,
        color: color,
        url: url,
        isExpire: false,
      });

      let itemDate;

      tempData?.map(datadate => {
        let val = datadate.date;
        itemDateObject = new Date(val);
        itemDate = itemDateObject.toString();

        if (cDate < itemDateObject) {
          datadate.isExpire = false;
        } else if (cDate > itemDateObject) {
          datadate.isExpire = true;
        }
        return datadate;
      });

      await AsyncStorage.setItem('ITEMS', JSON.stringify(tempData));
      setItems(tempData);

      navigation.goBack();
    } catch (e) {
      console.log(e);
    }
  };

  return (
    <View style={{ backgroundColor: '#b1f9f2', flex: 1 }}>
      <ScrollView>
         <TextInput style={{padding :15, backgroundColor:'turquoise', width:'90%',height:50, borderRadius:20, borderWidth:0.5, marginLeft: 10, marginTop:50}} placeholder="Name" value={name} onChangeText={txt=>setName(txt)}></TextInput>
      <TextInput style={{padding :15, backgroundColor:'turquoise', width:'90%',height:50, borderRadius:20, borderWidth:0.5, marginLeft: 10, marginTop:50}} placeholder="Quantity" value={quantity} onChangeText={txt=>setQuantity(txt)}></TextInput>
      <TextInput style={{padding :15,backgroundColor:'turquoise',  width:'90%',height:50, borderRadius:20, borderWidth:0.5, marginLeft: 10, marginTop:50}} placeholder="Date" value={date} onChangeText={txt=>setDate(txt)}></TextInput>
     
      <TextInput style={{padding :15, backgroundColor:'turquoise',  width:'90%',height:50,  borderRadius:20, borderWidth:0.5, marginLeft: 10, marginTop:50}} placeholder="Color" value={color} onChangeText={txt=>setColor(txt)}></TextInput>
    
     
<Text style={{color:'white',Textalign: 'center' , backgroundColor: 'turquoise', fontSize:12.5, marginTop: 50, marginLeft:30, borderRadius:20, width:300, alignItems:'center', textAlign:'center', fontWeight:'bold'}}>On the internet, copy the image url of your food item. For example if your food item is Nature's Own bread then you will copy the image link of an image of Nature's Own Bread and paste it down below! </Text>
  <TextInput style={{padding :15, backgroundColor:'turquoise',  width:'90%',height:50,borderRadius:20, borderWidth:0.5, marginLeft: 10, marginTop:50}} placeholder="Image Link " value={url} onChangeText={txt=>setUrl(txt)}></TextInput>
     
             
      <TouchableOpacity onPress={SaveItem} style={{justifyContent:'center', marginLeft: 10, alignItems:'center', width:"90%", height:50,marginTop:30, backgroundColor:'turquoise',borderRadius:20}}>
        <Text style={{color:'white', fontWeight:'bold'}}>Save</Text>
      </TouchableOpacity>
      </ScrollView>
      <View style={{ backgroundColor: '#b1f9f2', flex: 1, alignItems: 'center' }}>
        <TextInput
          style={{ padding: 15, width: '90%', height: 50, borderRadius: 20, borderWidth: 0.5, marginTop: 20 }}
          placeholder="Name"
          value={val}
          onChangeText={text => setVal(text)}
        />
        <TouchableOpacity
  style={{
    backgroundColor: 'turquoise',
    alignItems: 'center',
    height: 50,
    font: 'bold',
    width: 150,
    marginTop: 40,
    borderRadius: 10,
  }}
  onPress={async () => {
    await SaveItem();
    props.navigation.navigate('Qrgenerator', { data: val });
  }}
  title='Generate Value'
>
  <Text
    style={{
      color: 'white',
      fontSize: 15,
      fontWeight: 'bold',
      marginTop: 15,
      alignSelf: 'center',
    }}
  >
    Generate Value
  </Text>
</TouchableOpacity>
      </View>
    </View>
  );
};

export default AddProduct;
