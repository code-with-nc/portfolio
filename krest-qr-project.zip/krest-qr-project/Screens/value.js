import { StyleSheet, View, Text,TextInput, TouchableOpacity } from 'react-native'
import React, { useState,useEffect } from 'react'
import { useRoute} from '@react-navigation/native'

export default function Value(props) {
  const route= useRoute();
  const [val,setVal]=useState(0);
  return (
  
       <View style={{backgroundColor:"#b1f9f2", flex: 1, alignItems:'center', }}>
    <TextInput style= {{padding:15, width:'90%', height:50, borderRadius:20, borderWidth:0.5, marginTop:20,}} placeholder="Name" 
    value={val} onChangeText={text=>setVal(text)}   >
  
  </TextInput>
     
      <TouchableOpacity style= {{ backgroundColor:'turquoise', alignItems:'Center', height:50, font:'bold',width:150, marginTop:40,borderRadius:10,}}  onPress={() => {props.navigation.navigate('Qrgenerator',{data:val,})}} title='Generate Value'><Text style={{color:'white', fontSize:15, fontWeight:'bold', marginTop:15, alignSelf:'center', }}>Generate Value</Text></TouchableOpacity>
      
      
    </View>

  )

}