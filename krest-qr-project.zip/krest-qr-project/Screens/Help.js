import { View, Text, TouchableOpacity, Linking, StyleSheet} from 'react-native'
import React from 'react'

const Help = () => {
  return (
    <View style={{backgroundColor:"#b1f9f2", flex: 1}}>
      <Text style={{color:"transparent", fontSize:20, fontWeight:"bold", }}>rourheauhu</Text>
      <Text style={{color:"transparent",}}>rourheauhu</Text>
      <Text style={{color:"transparent",}}>rourheauhu</Text>
      <Text style={{color:"transparent",}}>rourheauhu</Text>
      <Text style={{color:"transparent",}}>rourheauhu</Text>
      <Text style={{color:"transparent",}}>rourheauhu</Text>
  
   <View style={{backgroundColor:"turquoise", borderRadius: 30, height:300, width:280, alignSelf: "center",}}>
      <Text style=
      {{fontSize:15, fontWeight:"bold", fontSize:20, backgroundColor:"turquoise", color:"white", 
       alignSelf:'center', textAlign:'center',}}>                                                                                   If you have any troubleshooting issues or any help please reach out regarding any concerns. please feel free to reach out to us. You will be able to reach us by Gmail by clicking the button below.</Text></View>    

    
  <TouchableOpacity
        style={styles.BasketballButton}
        onPress={() => Linking.openURL('https://mail.google.com/mail/u/0/#inbox?compose=GTvVlcRzBWZdDnLRnwGRWrxDPXwnlZQztKwCsgPjVkrzQCNzGWpNvxJDBwWZGwQChTBxTJMjFQQCV')}>
          
    
    
    
   
   <Text style={styles.BasketballText}>Gmail</Text>
    </TouchableOpacity>
 
     </View>


  )
}

export default Help;

const styles = StyleSheet.create(
  {
    container: {
        flex: 1,  
        alignItems: "center",
    justifyContent: "center",
    backgroundColor:"#b1f9f2"
    },

    BasketballText: {
        textAlign: "center",
                  color: "white",
                  // fontWeight:"bold",
                  fontSize: 18,
      },
    BasketballButton: {
      backgroundColor: "turquoise",
      alignSelf: 'center',
      padding: 10,
      width:200,
      marginTop: 150,
      margin: 80,
      height: 40,
      borderRadius: 10,
    },
    
  } 
    );