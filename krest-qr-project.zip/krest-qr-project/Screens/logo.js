import { View, Text } from 'react-native'
import React, {useEffect} from 'react'
import {useNavigation} from '@react-navigation/native'

function Logo(props){
  useEffect(()=>{
      setTimeout(() => {
          props.navigation.navigate("MainScreen")
      }, 3000);
  })
  return (

    <View style = {{ backgroundColor:"#b1f9f2", flex:1, flexDirection: 'row'}}>
      <Text style = {{fontSize: 50, marginBottom:200, marginLeft:100, color: 'turquoise', alignSelf:"center", fontWeight: 'bold'}}>KREST </Text>
      <Text style = {{fontSize:30, marginTop:280, marginLeft:-95,  color:'turquoise', fontWeight: 'bold'}}>X</Text>
            <Text style = {{fontSize:30, marginTop:310, marginLeft:-22,  color:'turquoise', fontWeight: 'bold'}}>P</Text>
        <Text style = {{fontSize:30, marginTop:340, marginLeft:-16,  color:'turquoise', fontWeight: 'bold'}}>I</Text>
         <Text style = {{fontSize:30, marginTop:370, marginLeft:-9,  color:'turquoise', fontWeight: 'bold'}}>R</Text>
             <Text style = {{fontSize:30, marginTop:400, marginLeft:-22,  color:'turquoise', fontWeight: 'bold'}}>A</Text>
                <Text style = {{fontSize:30, marginTop:430, marginLeft:-21,  color:'turquoise', fontWeight: 'bold'}}>T</Text>
                   <Text style = {{fontSize:30, marginTop:460, marginLeft:-15,  color:'turquoise', fontWeight: 'bold'}}>I</Text>
                          <Text style = {{fontSize:30, marginTop:490, marginLeft:-15,  color:'turquoise', fontWeight: 'bold'}}>O</Text>
                           <Text style = {{fontSize:30, marginTop:520, marginLeft:-20,  color:'turquoise', fontWeight: 'bold'}}>N</Text>
                            <Text style = {{fontSize:30, marginTop:280, marginLeft:40,  color:'turquoise', fontWeight: 'bold'}}>R</Text>
                                <Text style = {{fontSize:30, marginTop:310, marginLeft:-22,  color:'turquoise', fontWeight: 'bold'}}>A</Text>
              <Text style = {{fontSize:30, marginTop:340, marginLeft:-22,  color:'turquoise', fontWeight: 'bold'}}>C</Text>
               <Text style = {{fontSize:30, marginTop:370, marginLeft:-22,  color:'turquoise', fontWeight: 'bold'}}>K</Text>
               <Text style = {{fontSize:30, marginTop:400, marginLeft:-20,  color:'turquoise', fontWeight: 'bold'}}>E</Text>
                 <Text style = {{fontSize:30, marginTop:430, marginLeft:-20,  color:'turquoise', fontWeight: 'bold'}}>R</Text>
 


    </View>
  )
}

export default Logo