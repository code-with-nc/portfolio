import { StatusBar } from 'expo-status-bar';
import { StyleSheet, View } from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import {useRoute} from '@react-navigation/native' ;
export default function Qrgenerator() {
  const route = useRoute()
  return (
    <View style={styles.container}>
      <QRCode value={route.params.data}/>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#b1f9f2',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
