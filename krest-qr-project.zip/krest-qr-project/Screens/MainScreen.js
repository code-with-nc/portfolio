import React, { Component } from "react";
import {
  Text,
  TouchableOpacity,
  TextInput,
  StyleSheet,
  ScrollView,
  Alert,
  View
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";


const MainScreen = ({navigation}) =>
{ 
    return (
    <View style={styles.container}>

    <TouchableOpacity
        style={styles.submitButton}
        onPress={() => navigation.navigate("Home")}
        >
          
      <Text style={styles.submitButtonText}>Home</Text>
    </TouchableOpacity>
    
    <TouchableOpacity
        style={styles.submitButton}
        onPress={() => navigation.navigate("Qrscanner")}
        >
          
      <Text style={styles.submitButtonText}>QR Scanner</Text>
    </TouchableOpacity>

       <TouchableOpacity
        style={styles.submitButton}
        onPress={() => navigation.navigate("Value")}
        >
          
      <Text style={styles.submitButtonText}>QR Generator</Text>
    </TouchableOpacity>

    <TouchableOpacity
        style={styles.submitButton}
        onPress={() => navigation.navigate("Help")}
        >
          
      <Text style={styles.submitButtonText}>Help</Text>
    </TouchableOpacity>




        </View>
    );
}


export default MainScreen;


const styles = StyleSheet.create(
  {
    container: {
        flex: 1,  
        alignItems: "center",
    justifyContent: "center",
    backgroundColor:"#b1f9f2"
    },

    submitButtonText: {
        textAlign: "center",
                  color: "white",
                  // fontWeight:"bold",
                  fontSize: 18,
      },
    submitButton: {
      backgroundColor: "turquoise",
      padding: 10,
      width:200,
      margin: 10,
      height: 40,
    },
    
  } 
    );