import { View, Text,TouchableOpacity,FlatList, Image,ScrollView } from 'react-native'
import React, { useState,useEffect } from 'react'
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation,useIsFocused } from '@react-navigation/native';

const Expired = () => {
  const navigation = useNavigation();
  const isFocused = useIsFocused();
  const [Data, setData] = useState([]);
  const [exp,setExp] = useState('');
  const [exp1,setExp1] = useState('Expired')
  let currDateObject = new Date();
  
  useEffect(()=>{
    getData();
  },[isFocused])
  const getData = async () => {
    const getProducts= await AsyncStorage.getItem('ITEMS')
    console.log(getProducts,"getProducts")
    setData(JSON.parse(getProducts));
    // const St = await AsyncStorage.getItem('STATUS')
    // if(St=='OK')
    // {
    //   setExp("Good")
    // }
    // else if(St=='Expired'){
    //   setExp("Expired")
    // }
    //console.log(val);
  }
  const deleteData= async index =>{
     const tempData = Data;

     const selectedData = tempData.filter((item, ind) =>{
       return ind != index;
     })

     setData(selectedData);
     await AsyncStorage.setItem('ITEMS', JSON.stringify(selectedData))
  }

    
  
  
  //console.log(exp)
         console.log(Data);
  
   
  const update = ()=>{
    
    deleteData(index);

  }
  return (
    
   <View style={{backgroundColor:"#b1f9f2", flex:1}}>
      <FlatList 
       data ={Data}
       renderItem={({item,index})=>{
        return(
           <View>
          {item.isExpire==true ?<View style={{width:'95%',alignSelf:'center',borderRadius:10,marginTop:5,borderWidth:1,flexDirection:'row',paddingLeft:5,backgroundColor:'white',height:430}}>
          <View style={{flex:1,flexDirection:'column',}}>
           <ScrollView style={{}}>
           <Text style={{fontSize:30,fontWeight:'bold',alignSelf:'center'}}>{item.name.toUpperCase()}</Text>
           <Image style={{borderRadius:2,height:300,width:"100%"}} source={{uri:item.url}}></Image>
           <View style={{flexDirection:'row',marginTop:5}}>
           <Text style={{ fontWeight:'bold',color:'grey'}}>Quantity - {item.quantity.toUpperCase()}</Text>
          
           <Text style={{marginLeft:141,fontWeight:'bold',color:'grey',position:'absolute'}}>Date - {item.date.toUpperCase()}</Text>
           </View>
            <View style={{flexDirection:'row',marginTop:5,}}>
           <Text  style={{color:'grey'}}>Color - {item.color.toUpperCase()}</Text>
           
              
          <Text style={{marginLeft:141,color:'grey',position:'absolute'}}>Status - Expired</Text>
          </View>
          <View style={{flexDirection:'row'}}>
             <TouchableOpacity onPress={()=>{deleteData(index); navigation.navigate('AddProduct')}} style={{backgroundColor:'turquoise', padding:5,alignItems:'center',justifyContent:'center',marginTop:5}}>
            <Text>Update</Text>
           </TouchableOpacity>
          <TouchableOpacity onPress={()=>{deleteData(index)}} style={{backgroundColor:'turquoise', padding:5,alignItems:'center',justifyContent:'center',marginTop:5,marginLeft:86}}>
            <Text>Delete</Text>

           </TouchableOpacity>
          </View>
          </ScrollView>
           
           </View>
         
           </View>:<></>}
          </View>
        )
       }}
      />
      <View style={{flex:1,marginTop:90}}>
      <TouchableOpacity onPress={()=>{navigation.navigate('AddProduct')}} style={{justifyContent:'center',alignItems:'center',width:90, height:50,bordrRadius:30,backgroundColor:'turquoise',position:'absolute', bottom:20,right:20,}}>
      <Text style={{color:'white'}}>Add</Text>
      </TouchableOpacity>
        <TouchableOpacity onPress={()=>{navigation.navigate('Ok')}} style={{justifyContent:'center',alignItems:'center',width:90, height:50,bordrRadius:30,backgroundColor:'turquoise',position:'absolute', bottom:20,center:5,alignSelf:'center'}}>
      <Text style={{color:'white'}}>Good</Text>
      </TouchableOpacity>
       <TouchableOpacity onPress={()=>{navigation.navigate('Expired')}} style={{justifyContent:'center',alignItems:'center',width:90, height:50,bordrRadius:30,backgroundColor:'turquoise',position:'absolute', bottom:20,left:20}}>
      <Text style={{color:'white'}}>Expired</Text>
      </TouchableOpacity>
    </View>
    </View>
    
  
  )
}

export default Expired

