import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View , FlatList, TouchableOpacity, ScrollView, SafeAreaView, Image} from 'react-native';
import React, { Component } from "react"; 
import * as SecureStore from 'expo-secure-store';

let AUTHORS = [
 
 
];




const AuthorInfo = ({ name, date, quantity, calories, image, expiry_date }) => (
   
 
 <View style={styles.item}>

    <Text >{"Name: " + name}</Text>
    <Text style={styles.sectionDescription}>{"Date: " + date}</Text>
    <Text style={styles.sectionDescription}>{"Expiery Date: " + expiry_date}</Text>
    <Text style={styles.sectionDescription}>{"Quantity: " + quantity}</Text>
    <Text style={styles.sectionDescription}>{"Calories: " + calories}</Text>
    {/* <Image  style={styles.cardImage} source = {{uri:image}}></Image> */}

  </View>
);
const Menu  = ({navigation}) =>
{

    const [exampleState, setExampleState] = React.useState(AUTHORS)

  let res = ""

  getname('products')

    //Get data from DB
    async function getname (key) {
        let result = await SecureStore.getItemAsync(key);
         
        var newstr = result.replace("[,","[")
      
    
        const resultJson = JSON.parse(newstr)

       
     
        setExampleState(resultJson)
      
        // if(result) {
        //   onChangeResult(result);
        // } else {
        //   alert('Not Found');
        // }
      
      }

  // getData()

  //SecureStore.deleteItemAsync('products')

    async function getData() {
    res =  await SecureStore.getItemAsync('products');

  const resultJson = JSON.parse(res)



  AUTHORS = resultJson 

  //console.log(res+"11")
         
  }



  const renderItem = ({ item }) => (
   
    <AuthorInfo name={item.name} date={item.date} expiry_date={item.expiry_date} quantity={item.quantity} calories={item.calories} />
   
    );

  const SeparatorComponent = () => {
    return <View style={styles.separatorLine} />;
  };

  const HeaderComponent = () => {
    return (
      <View style={styles.sectionContainer}>
        <Text style={styles.sectionDescription}>My List of Food Items !!</Text>
      </View>
    );
  };

  const FooterComponent = () => {
    return (
      <View style={styles.sectionContainer}>
        <Text style={styles.sectionDescription}>
          @ All rights reserved by Jonathan 2022.
        </Text>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={exampleState}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        ItemSeparatorComponent={SeparatorComponent}
        ListHeaderComponent={HeaderComponent}
        ListFooterComponent={FooterComponent}
        
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#DEFCF9",
    flex: 1,
    marginTop: StatusBar.currentHeight || 0,
  },
  item: {
    padding: 20,
    marginTop: 20,
    backgroundColor: "tuquoise",
    marginBottom: 10,
    marginLeft: "2%",
    width: "96%",
    flexDirection:'column',
    
    borderRadius: 12,
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowRadius: 0.5,
    shadowOffset: {
      width: 1,
      height: 1,
    },
  },
  title: {
    fontSize: 20,
  },
  separatorLine: {
    height: 1,
    // backgroundColor: "light_grey",
    paddingTop: 2,
  },
  sectionContainer: {
    marginTop: 32,
    paddingHorizontal: 24,
  },
  footer: {
    paddingBottom: 30,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: "600",
    color: "black",
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: "200",
    color: "black",
  },
  sectionproduct: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: "400",
    color: "black",
  },
  cardImage: {
    width: "100%",
    height: 200,
    resizeMode: "cover" 
  },


 
});

export default Menu;







