import "react-native-gesture-handler";
import { StatusBar } from "expo-status-bar";
import React from "react";
import { StyleSheet, Text, View } from "react-native";

import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";

 import Home from "./Screens/Home";
import MainScreen from "./Screens/MainScreen";
import AddProduct from "./Screens/AddProduct";
import Menu from "./Screens/Menu";
import Expired from "./Screens/Expired";
import Help from "./Screens/Help";
import Qrgenerator from "./Screens/Qrgenerator";
import Qrscanner from "./Screens/Qrscanner";
import Ok from "./Screens/Ok";
import Value from "./Screens/value";
import Logo from "./Screens/logo";
const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Logo">
        <Stack.Screen
          name="MainScreen"
          component={MainScreen}
          options={{
            title: "Expired App",
            headerStyle: {
              backgroundColor: "turquoise",
            },
            headerTintColor: "#fff",
            headerTitleStyle: {
              fontWeight: "bold",
            },
          }}
        ></Stack.Screen>


<Stack.Screen
          name="AddProduct"
          component={AddProduct}
          options={{
            title: "Add Product",
            headerStyle: {
              backgroundColor: "turquoise",
            },
            headerTintColor: "#fff",
            headerTitleStyle: {
              fontWeight: "bold",
            },
          }}
        ></Stack.Screen>



<Stack.Screen
          name="Menu"
          component={Menu}
          options={{
            title: "Menu",
            headerStyle: {
              backgroundColor: "turquoise",
            },
            headerTintColor: "#fff",
            headerTitleStyle: {
              fontWeight: "bold",
            },
          }}
        ></Stack.Screen>

<Stack.Screen
          name="Home"
          component={Home}
          options={{
            title: "Home",
            headerStyle: {
              backgroundColor: "turquoise",
            },
            headerTintColor: "#fff",
            headerTitleStyle: {
              fontWeight: "bold",
            },
          }}
        ></Stack.Screen>




<Stack.Screen
          name="Expired"
          component={Expired}
          options={{
            title: "Expired ",
            headerStyle: {
              backgroundColor: "turquoise",
            },
            headerTintColor: "#fff",
            headerTitleStyle: {
              fontWeight: "bold",
            },
          }}
        ></Stack.Screen>

<Stack.Screen
          name="Help"
          component={Help}
          options={{
            title: "Help",
            headerStyle: {
              backgroundColor: "turquoise",
            },
            headerTintColor: "#fff",
            headerTitleStyle: {
              fontWeight: "bold",
            },
          }}
        ></Stack.Screen>

        <Stack.Screen
          name="Value"
          component={Value}
          options={{
            title: "Value",
            headerStyle: {
              backgroundColor: "turquoise",
            },
            headerTintColor: "#fff",
            headerTitleStyle: {
              fontWeight: "bold",
            },
          }}
        ></Stack.Screen>

<Stack.Screen
          name="Ok"
          component={Ok}
          options={{
            title: "Good",
            headerStyle: {
              backgroundColor: "turquoise",
            },
            headerTintColor: "#fff",
            headerTitleStyle: {
              fontWeight: "bold",
            },
          }}
        ></Stack.Screen>

         <Stack.Screen
          name="Qrgenerator"
          component={Qrgenerator}
          options={{
            title: "QR generator",
            headerStyle: {
              backgroundColor: "turquoise",
            },
            headerTintColor: "#fff",
            headerTitleStyle: {
              fontWeight: "bold",
            },
          }}
        ></Stack.Screen>

           <Stack.Screen
          name="Qrscanner"
          component={Qrscanner}
          options={{
            title: "QR Scanner",
            headerStyle: {
              backgroundColor: "turquoise",
            },
            headerTintColor: "#fff",
            headerTitleStyle: {
              fontWeight: "bold",
            },
          }}
        ></Stack.Screen>

<Stack.Screen
          name="Logo"
          component={Logo}
          options={{
            title: "Logo",
            headerStyle: {
              backgroundColor: "turquoise",
            },
            headerTintColor: "#fff",
            headerTitleStyle: {
              fontWeight: "bold",
            },
          }}
        ></Stack.Screen>
      
  
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#DEFCF9",
    alignItems: "center",
    justifyContent: "center",
  },
});
