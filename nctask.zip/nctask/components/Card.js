import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import {Card} from 'react-native-paper';

export default function BCard() {
  return (
    <View style={styles.container}>
     <Card style={styles.cards}>
      <Image style={styles.logo} source={require('../assets/R.png')} />
      <Image source={require('../assets/N.jpg')}/>
      <Text style={styles.custom}> HEllO BROTHER </Text>
     
     </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },

  cards:{ 
    borderWidth:1,
    borderColor:'grey',
    height:230 ,
    borderRadius: 5,
    marginHorizontal: 8,
    justifyContent:'center',
    alignItems:'center',
  },

  logo: {
    height: 205,
    width: 260,
    justifyContent:'center',
    alignItems:'center',
  }
});
