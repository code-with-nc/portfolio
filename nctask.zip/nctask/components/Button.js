import React from 'react';
import { View, FlatList, TouchableOpacity, Text, StyleSheet } from 'react-native';

const data = [
  { id: 1, text: 'Item 1' },
  { id: 2, text: 'Item 2' },
  { id: 3, text: 'Item 3' },
  { id: 4, text: 'Item 4' },
  { id: 5, text: 'Item 5' },
  { id: 5, text: 'Item 6' },
  { id: 5, text: 'Item 7' },
  { id: 5, text: 'Item 8' },
];

const MyFlatList = () => {
  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.itemContainer}
      onPress={() => handlePress(item)}
    >
      <Text style={styles.itemText}>{item.text}</Text>
    </TouchableOpacity>
  );

  const handlePress = (item) => {
    // Handle item press here
    console.log('Item pressed:', item);
  };

  return (
    <View style={styles.container}>
      <FlatList
        horizontal
        data={data}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
        
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 10,
    backgroundColor: '#F5F5F5',
  },
  itemContainer: {
    padding: 10,
    borderWidth:1,
    borderColor:'grey',
    height:40,
    borderRadius: 30,
    marginHorizontal: 8,
    justifyContent:'center',
    alignItems:'center',
  },
  itemText: {
    fontSize: 14,
    fontWeight:'bold',
    color: 'black',
  },
});

export default MyFlatList;