import React from "react";
import {View,Text,Image,StyleSheet} from 'react-native'

function LoadBackground() {
  const [isLoading, setIsLoading] = React.useState(true);
  const [data, setData] = React.useState([]);

  React.useEffect(() => {
    const url = "https://randomuser.me/api/?results=15";
    fetch(url)
      .then((response) => response.json())
      .then((json) => setData(json['results']))
      .catch((error) => console.log(error));
  }, []);

  React.useEffect(() => {
    if (data.length !== 0) {
      setIsLoading(false);
    }
    console.log(data); 
  }, [data]);

  return (
    <View>
      {isLoading ? (
        <Text>Loading...</Text>
      ) : (
        data.map((user) => (
          <View style={styles.card}>
          <Text style={{fontSize:30}}>

           {user.name.title} {user.name.first} {user.name.last}
          </Text>
          <Image style={{height:100,width:150}} source={{uri:user.picture.thumbnail}}></Image>
          </View>
        ))
      )}
    </View>
  );
}
const styles = StyleSheet.create({
  card:{}
});

export default LoadBackground;