import React from 'react';
import { View, Button, Text, StyleSheet } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { Ionicons } from '@expo/vector-icons';
import { ContactScreen } from './TabScreen/ContactScreen';
import  HomeScreen  from './TabScreen/HomeScreen';
import LiveClass from './TabScreen/LiveClass';



export function MainScreen(props: any) {

    const Tab = createBottomTabNavigator();

    return (
      
        <Tab.Navigator
            screenOptions={({ route }) => ({
                tabBarIcon: ({ focused, color, size }) => {
                    let iconName='';

                    if(route.name === 'HomeScreen') {
                      iconName = 'ios-home';
                    }
                   
                     else if(route.name === 'Doubts') {
                        iconName = 'ios-call';
                    }
                     else if(route.name === 'LiveClass') {
                        iconName = 'ios-people';
                    }

                    return <Ionicons name={iconName} size={size} color={color} />;
                },
                

            })}>
            
            <Tab.Screen name="HomeScreen" component={HomeScreen} />
            <Tab.Screen name="LiveClass" component={LiveClass} />
            <Tab.Screen name="Doubts" component={ContactScreen} />
            
        </Tab.Navigator>

    );
}
