
import './polyfills';


import {AntDesign} from '@expo/vector-icons';


import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';

import { MainScreen } from './MainScreen';
import  MyOrder  from './Screen/MyOrder';         
import { ContactScreen } from './TabScreen/ContactScreen';
import FAQ  from './Screen/FAQ';
import Books from './Screen/books';
import Ebook  from './Screen/Ebook';
import PrivacyPolicy  from './Screen/PrivacyPolicy';
import Refer  from './Screen/Refer';
import TestSeries from './Screen/TestSeries';
import LogOut  from './Screen/LogOut';
import MyProfile  from './Screen/MyProfile';


const Drawer = createDrawerNavigator();

export default function App() {
	return (
		<NavigationContainer>
			<Drawer.Navigator initialRouteName="Home"
        screenOptions={({ route }) => ({
                drawerIcon: ({ focused, color, size }) => {
                    let iconName='';

                    if(route.name === 'Home') {
                      iconName = 'home';
                    }
                     else if(route.name === 'E-books') {
                        iconName = 'tablet1';
                    }
                     else if(route.name === 'TestSeries') {
                        iconName = 'form';
                    }
                     else if(route.name === 'My Order') {
                        iconName = 'shoppingcart';
                    }
                     else if(route.name === 'Books') {
                        iconName = 'book';
                    }
                     else if(route.name === 'FAQ') {
                        iconName = 'questioncircle';
                    }
                     else if(route.name === 'Privacy Policy') {
                        iconName = 'solution1';
                    }
                     else if(route.name === 'Refer/Share App') {
                        iconName = 'sharealt';
                    }
                     else if(route.name === 'Call us/Helpline') {
                        iconName = 'customerservice';
                    }
                     else if(route.name === 'My Profile') {
                        iconName = 'user';
                    }
                     else if(route.name === 'Log Out') {
                        iconName = 'logout';
                    }

                    return  <AntDesign name={iconName} size={size} color={color} />;
                    
                },
             })
            }>
				<Drawer.Screen name="Home" component={MainScreen} />
        <Drawer.Screen name="E-books" component={Ebook} />
        <Drawer.Screen name="TestSeries" component={TestSeries} />
				<Drawer.Screen name="My Order" component={MyOrder} />
        <Drawer.Screen name="Books" component={Books} /> 
        <Drawer.Screen name="FAQ" component={FAQ} /> 
        <Drawer.Screen name="Privacy Policy" component={PrivacyPolicy} />
        <Drawer.Screen name="Refer/Share App" component={Refer} />
        <Drawer.Screen name="Call us/Helpline" component={ContactScreen} />
        <Drawer.Screen name="My Profile" component={MyProfile} /> 
        <Drawer.Screen name="Log Out" component={LogOut} /> 
			</Drawer.Navigator>
		</NavigationContainer>

	);
}

