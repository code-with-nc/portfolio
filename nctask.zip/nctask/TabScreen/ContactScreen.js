import React from 'react';
import { View, Button, Text, StyleSheet } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';

import  ContactA  from '../Screen/ContactA';
import  ContactB  from '../Screen/ContactB';

export function ContactScreen(props: any) {

    const Stack = createStackNavigator();

    return (
   
        <Stack.Navigator initialRouteName="ContactA">
            <Stack.Screen name="ContactA" component={ContactA} />
            <Stack.Screen name="ContactB" component={ContactB} />
        </Stack.Navigator>
      
    );
}