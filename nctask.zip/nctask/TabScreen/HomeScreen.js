import {View,Text} from 'react-native';
import LoadBackground from '../components/Json';


export default function HomeScreen(){
  return(
<View >
 
 <LoadBackground/>
  </View>
  );
}