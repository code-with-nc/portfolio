import {View,Text,Image} from 'react-native';

export default function LiveClass(){
  return(
  <View><Text>LiveClass</Text>
    <Image style={{height:300,widht:200}} source={{uri:'https://im.rediff.com/cricket/2023/jan/17kohli1.jpg'}}></Image>
  </View>
  )
}