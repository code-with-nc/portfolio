import {View,Text} from 'react-native';

export default function ContactB(){
  return(
  <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
    <Text>Contact B</Text>
  </View>
  )
}
