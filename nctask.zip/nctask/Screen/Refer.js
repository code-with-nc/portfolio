import { Button, View,Text } from 'react-native';

function Refer({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>
      Refer page
      </Text>
    </View>
  );
}

export default Refer;