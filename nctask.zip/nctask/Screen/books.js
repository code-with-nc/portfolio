import { Button, View,Text } from 'react-native';
import BCard from '../components/Card';

function Books({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>
      book page
      </Text>
      <BCard/>
    </View>
  );
}

export default Books