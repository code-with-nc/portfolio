import { Button, View,Text } from 'react-native';

function PrivacyPolicy({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>
       PrivacyPolicy page
      </Text>
    </View>
  );
}

export default  PrivacyPolicy;