import {View,Text,Button} from 'react-native';

export default function ContactA(props){
  return(
  <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
  
    <Text>Contact A</Text>
    <Button onPress={()=>{props.navigation.navigate('ContactB')}} title='Contact B'></Button>
    <Text>oo helo kya??? kaam karo bae</Text>
  </View>
  )
}