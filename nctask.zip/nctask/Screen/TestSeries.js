import { Button, View,Text } from 'react-native';

function TestSeries({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>
      TestSeries page
      </Text>
    </View>
  );
}

export default TestSeries;