import { Button, View,Text } from 'react-native';

function Ebook({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>
      Ebook page
      </Text>
    </View>
  );
}

export default Ebook;