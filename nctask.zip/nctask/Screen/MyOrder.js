import {View,Text} from 'react-native';
import MyflatList from '../components/Button';

export default function MyOrder(){
  return(
  <View style={{flex:1}}>
         <MyflatList/>
  </View>
  )
}