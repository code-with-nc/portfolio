import { Button, View } from 'react-native';



function Notifications({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Button onPress={() => navigation.navigate('Books')} title="Go to books" />
      <Button onPress={() => navigation.goBack()} title="Go back to home" />
    </View>
  );
}

export default Notifications