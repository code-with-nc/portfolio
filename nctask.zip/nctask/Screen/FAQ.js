import { Button, View ,Text} from 'react-native';



function FAQ({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
     <Text>
       FAQ page
     </Text>
    </View>
  );
}

export default FAQ