import {View,Text,Button} from 'react-native';

export default function LogOut(props){
  return(
  <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
  
    <Text>GO TO HOME</Text>
    <Button onPress={()=>{props.navigation.navigate('Home')}} title='Log Out'></Button>
  </View>
  )
}